# CV 
## Get started 

A header file can be compiled to a CV with cv-contents.tex . 

Headerfile with contact    :`cv-header-w-contacts.tex`
Headerfile with no contact :`cv-header-w-no-contacts.tex`

contents :`cv-contents.tex`

